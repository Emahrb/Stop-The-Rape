package com.emahrb.stoptherape;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SplashScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        Thread mThread = new Thread(){

            @Override
            public void run() {
                try {
                    sleep(4000);
                    Intent i = new Intent(SplashScreenActivity.this, MainActivity.class);
                    finish();
                    startActivity(i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
            mThread.start();

    }
}
