package com.emahrb.stoptherape;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button knowButton, emmergencyButton, helpLineButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        knowButton = (Button) findViewById(R.id.knowButton);
        emmergencyButton = (Button) findViewById(R.id.emmegencyButton);
        helpLineButton = (Button) findViewById(R.id.helpButton);


        knowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, InformationActivity.class);
                startActivity(i);
            }
        });

        emmergencyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(i);
            }
        });

        helpLineButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, HelpLineActivity.class);
                startActivity(i);
            }
        });




    }
}
